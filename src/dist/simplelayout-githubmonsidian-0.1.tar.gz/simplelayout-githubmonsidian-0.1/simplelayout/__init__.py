from src.simplelayout.__main__ import main  # noqa
